/*
 * prot_appl.h
 *
 *  Created on: 23 nov 2021
 *      Author: cecca
 */



#ifndef PROTAPPL_H_
#define PROTAPPL_H_

#define BUFF 512
#define PROTOPORT 27015


#endif /* PROTAPPL_H_ */
