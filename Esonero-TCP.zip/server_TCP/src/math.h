/*
 * math.h
 *
 *  Created on: 24 nov 2021
 *      Author: cecca
 */

#ifndef MATH_H_
#define MATH_H_

int add(int a, int b) {
	return a + b;
}

int mult(int a, int b) {
	return a * b;
}

int sub(int a, int b) {
	return a - b;
}
;
float division(int a, int b) {
	return (float)a / b;
}



#endif /* MATH_H_ */
